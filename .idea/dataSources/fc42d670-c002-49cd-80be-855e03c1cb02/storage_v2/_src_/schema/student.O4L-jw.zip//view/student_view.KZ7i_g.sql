create definer = root@localhost view student_view as
select `student`.`student`.`id` AS `id`, `student`.`student`.`name` AS `name`
from `student`.`student`;

