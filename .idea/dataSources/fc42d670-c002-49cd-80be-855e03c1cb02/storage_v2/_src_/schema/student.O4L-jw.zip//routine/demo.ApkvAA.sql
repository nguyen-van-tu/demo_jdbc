create
    definer = root@localhost procedure demo()
begin
    select * from student;
end;

