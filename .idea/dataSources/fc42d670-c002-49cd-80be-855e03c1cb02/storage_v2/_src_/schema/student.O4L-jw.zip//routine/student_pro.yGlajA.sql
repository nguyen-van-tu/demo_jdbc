create
    definer = root@localhost procedure student_pro()
begin
    select * from student;
    select * from classes;
end;

