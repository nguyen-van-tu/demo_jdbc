create definer = root@localhost view studen_view as
select `student`.`student`.`id` AS `id`, `student`.`student`.`name` AS `name`
from `student`.`student`;

