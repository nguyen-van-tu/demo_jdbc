create definer = root@localhost view classes_view as
select `student`.`classes`.`id` AS `id`, `student`.`classes`.`name` AS `name`
from `student`.`classes`;

