create definer = root@localhost view vw_ctpnhap_vt_pn as
select `p`.`ma_phieu_nhap`                    AS `ma_phieu_nhap`,
       `p`.`ngay_nhap`                        AS `ngay_nhap`,
       `d`.`ma_don`                           AS `ma_don`,
       `v`.`ma_vattu`                         AS `ma_vattu`,
       `v`.`ten_vattu`                        AS `ten_vattu`,
       `ct`.`sl_nhap`                         AS `sl_nhap`,
       `ct`.`don_gia_nhap`                    AS `don_gia_nhap`,
       (`ct`.`sl_nhap` * `ct`.`don_gia_nhap`) AS `totalMoney`
from (((`quanlivattu`.`ct_phieu_nhap` `ct` join `quanlivattu`.`phieu_nhap` `p` on ((`ct`.`id_ctpn` = `p`.`id_pn`))) join `quanlivattu`.`vattu` `v` on ((`ct`.`id_ctpn` = `v`.`id_vt`)))
         join `quanlivattu`.`don_dat_hang` `d` on ((`ct`.`id_ctpn` = `d`.`id_ddh`)));

