create definer = root@localhost view vw_ctpnhap as
select `p`.`id_pn`                            AS `id_pn`,
       `v`.`ma_vattu`                         AS `ma_vattu`,
       `ct`.`sl_nhap`                         AS `sl_nhap`,
       `ct`.`don_gia_nhap`                    AS `don_gia_nhap`,
       (`ct`.`sl_nhap` * `ct`.`don_gia_nhap`) AS `totalMoney`
from ((`quanlivattu`.`ct_phieu_nhap` `ct` join `quanlivattu`.`phieu_nhap` `p` on ((`ct`.`id_ctpn` = `p`.`id_pn`)))
         join `quanlivattu`.`vattu` `v` on ((`ct`.`phieu_nhap_id` = `v`.`id_vt`)));

