create
    definer = root@localhost procedure demo1(IN name1 varchar(255))
begin
    select * from student where name = name1;
end;

