create definer = root@localhost view view133 as
select `studen_manager`.`student`.`id` AS `id`, `studen_manager`.`student`.`name` AS `name`
from `studen_manager`.`student`;

